<?php

    $conn = new mysqli("localhost", "u314764576_itbg", "Yahoocom12", "u314764576_bgy_system") or die("Unable to connect");

?>