<?php 
session_start();
include("../phpfiles/connection.php");
if(isset($_SESSION['user_id']))
{ 
    $query = "select * from tbluser where id = '" . $_SESSION['user_id'] . "' limit 1";
    $result = mysqli_query($conn, $query);
    $user_data = mysqli_fetch_assoc($result);

    
    if($_SESSION['user_id'] != ""){
        if($user_data['type'] == 'user'){
            header("location:../Residents/dashboard/dashboard.php");
        }else if($user_data['type'] == 'admin'){
            header("location:../Admin/dashboard/dashboard.php");
        } 
    }
}

function itexmo($email,$password,$number,$message,$apicode)
{
    $ch = curl_init();
    $recipient = array();
    array_push($recipient, $number);
    $itexmo = array('Email' => $email,  'Password' => $password, 'ApiCode' => $apicode, 'Recipients' => $recipient, 'Message' => $message);
    curl_setopt($ch, CURLOPT_URL,"https://api.itexmo.com/api/broadcast");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,http_build_query($itexmo));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    return curl_exec ($ch);
    curl_close ($ch);
}

if(isset($_POST['continue']))
{
    $cnumber = $_POST['cnumber'];

    $query = "SELECT U.*, S.contactnumber FROM tbluser U INNER JOIN resident_table S ON U.id = S.user_id WHERE S.contactnumber = $cnumber;";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    $_SESSION['uid'] = $row['id'];

    if (mysqli_num_rows($result)==0){
        $_SESSION['message'] = 'contact number does not exists';
        header("location:forgot.php");
    }
    else
    {
        $otpcode = rand(100000, 999999); 
        $query = "UPDATE tbluser SET code = '$otpcode' WHERE id = '" . $_SESSION['uid']. "';";
        $result = mysqli_query($conn, $query);

        $smsemail = "bernard.mazo04@gmail.com";
        $password = "Mazo20181132826";
        $apicode = "PR-BERNA461967_SZ8D9";
        $number = $cnumber;
        $message = "OTP CODE - Your password reset code is ". $otpcode. ".";

        itexmo($smsemail, $password, $number, $message, $apicode);
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <title>Code Verification</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css"/>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

</head>

<body background="images/<?php
        include("../phpfiles/bgy_info.php");
        echo $row[7];
        ?>">
    
    <div class="login">
        <div style="text-align: center;">
            <h1 class="mb-3">Code Verification</h1>
        </div>
        
        <?php 
        if(isset($_SESSION['message']) && $_SESSION['message'] != ''){?>
            <div class="alert alert-danger mt-2" role="alert">
                <?php echo $_SESSION['message'] ?>
            </div> 
        <?php 
        }
        else {
        ?>
            <div class="alert alert-success mt-2" role="alert">
                We've sent a password reset OTP to your contact number - <?php echo $cnumber ?>
            </div> 
        <?php 
        $_SESSION['message'] = '';
        }
        ?>
        <form action="new_password.php" method="post">
            <div class="form-group was-validated">
                <input class="form-control" type="text" name="otpcode" id="otpcode" oninput="this.value = this.value.replace(/[^0-9]/gi, '').replace(/(\..*)\./gi, '$1')" required>
                <div class="invalid-feedback">
                    Please enter the code
                </div>
            </div>
            <!--<div class="form-group form-check">
                <input class="form-check-input" type="checkbox" id="check">
                <label class="form-check-label" for="check">Remember me</label>
            </div>-->
            <div class="row mt-0 pt-0 px-2">
                <div class="col p-1">
                    <input class="btn btn-primary w-100" type="submit" name ="submit_code" value="Submit">
                    <input type="hidden" name="u_id" value="<?php echo $user_id;?>">
                </div>
            </div>
        </form>
    </div>

</body>
</html>