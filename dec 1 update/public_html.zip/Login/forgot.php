<?php 
session_start();
include("../phpfiles/connection.php");
if(isset($_SESSION['user_id']))
{ 
    $query = "select * from tbluser where id = '" . $_SESSION['user_id'] . "' limit 1";
    $result = mysqli_query($conn, $query);
    $user_data = mysqli_fetch_assoc($result);

    
    if($_SESSION['user_id'] != ""){
        if($user_data['type'] == 'user'){
            header("location:../Residents/dashboard/dashboard.php");
        }else if($user_data['type'] == 'admin'){
            header("location:../Admin/dashboard/dashboard.php");
        } 
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <title>Forgot Password</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css"/>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

</head>

<body background="images/<?php
        include("../phpfiles/bgy_info.php");
        echo $row[7];
        ?>">
    
    <div class="login">
        <div style="text-align: center;">
            <h1 class="mb-3">Forgot Password</h1>
            <h6>Enter your contact number</h6>
            <br>
        </div>
        <?php 
        if(isset($_SESSION['message']))
        {
            if($_SESSION['message'] != ''){?>
            <div class="alert alert-danger mt-2" role="alert"><?php echo $_SESSION['message'];?></div> 
        <?php }
        }
        
        $_SESSION['message'] = ''?>
        <form action="code_verification.php" method="post">
            <div class="form-group was-validated">
                <input class="form-control" type="text" name="cnumber" id="cnumber" oninput="this.value = this.value.replace(/[^0-9]/gi, '').replace(/(\..*)\./gi, '$1')" required>
                <div class="invalid-feedback">
                    Please enter your contact number
                </div>
            </div>
            <!--<div class="form-group form-check">
                <input class="form-check-input" type="checkbox" id="check">
                <label class="form-check-label" for="check">Remember me</label>
            </div>-->
            <div class="row mt-0 pt-0 px-2">
                <div class="col p-1">
                    <input class="btn btn-primary w-100" type="submit" name ="continue" value="Continue">
                </div>
            </div>
        </form>
    </div>

</body>
</html>