<?php

    $conn = new mysqli("localhost", "root", "", "bgy_system") or die("Unable to connect");

?>